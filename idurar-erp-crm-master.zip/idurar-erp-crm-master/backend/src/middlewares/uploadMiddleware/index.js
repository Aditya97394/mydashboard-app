const singleStorageUpload = require('./singleStorageUpload');

module.exports = {
  singleStorageUpload,
};
