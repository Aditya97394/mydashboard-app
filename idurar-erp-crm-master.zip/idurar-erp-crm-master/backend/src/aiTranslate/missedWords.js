module.exports = {
  date_format: 'Date Format',
  server_url: 'Server Url',
};
